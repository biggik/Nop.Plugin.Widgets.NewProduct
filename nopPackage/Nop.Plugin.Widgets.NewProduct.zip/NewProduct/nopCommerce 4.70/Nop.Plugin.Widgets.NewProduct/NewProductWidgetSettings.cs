﻿using Nop.Core.Configuration;

namespace Nop.Plugin.Widgets.NewProduct
{
    public class NewProductWidgetSettings : ISettings
    {
        public string WidgetZones { get; set; }
        public string DisplayText { get; set; }
    }
}
